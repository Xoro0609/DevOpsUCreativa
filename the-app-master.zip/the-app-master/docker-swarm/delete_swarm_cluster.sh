#!/bin/sh
set -e

docker-machine rm local swarm-master swarm-agent-00 swarm-agent-01 swarm-agent-02

