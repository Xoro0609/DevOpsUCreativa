package io.github.zutherb.appstash.shop.repository.cart.impl;

import org.junit.Test;

import static org.junit.Assert.*;

public class CartRepositoryImplTest {

    @Test
    public void testCreate() throws Exception {

    }

    @Test
    public void testAdd() throws Exception {

    }

    @Test
    public void testRemoveFromCart() throws Exception {

    }

    @Test
    public void testClear() throws Exception {

    }

    @Test
    public void testGetCartItems() throws Exception {

    }
}