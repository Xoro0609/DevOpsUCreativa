package io.github.zutherb.appstash.shop.repository.order.api;

/**
 * @author zutherb
 */
public interface OrderIdProvider {
    Long nextVal();
}
