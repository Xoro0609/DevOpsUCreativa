package io.github.zutherb.appstash.shop.ui.event.cart;

import io.github.zutherb.appstash.shop.ui.event.AjaxEvent;

/**
 * @author zutherb
 *         <p>
 *         marker interface
 */
public interface CartChangeEvent extends AjaxEvent { /* NOOP */
}
