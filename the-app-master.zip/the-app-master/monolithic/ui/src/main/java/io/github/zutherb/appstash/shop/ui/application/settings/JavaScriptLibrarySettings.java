package io.github.zutherb.appstash.shop.ui.application.settings;

public class JavaScriptLibrarySettings extends AbstractJavaScriptLibrarySettings {

    public JavaScriptLibrarySettings () {
        super();
        setJQueryPath("jquery/jquery-1.9.1.min.js");
    }

}
