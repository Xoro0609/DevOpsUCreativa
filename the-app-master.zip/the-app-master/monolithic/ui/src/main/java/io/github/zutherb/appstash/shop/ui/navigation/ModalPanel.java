package io.github.zutherb.appstash.shop.ui.navigation;

/**
 * @author zutherb
 */
public interface ModalPanel {
    String generateToggleScript();
}
